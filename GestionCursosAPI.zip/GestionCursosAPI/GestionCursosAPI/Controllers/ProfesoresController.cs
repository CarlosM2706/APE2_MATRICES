﻿using GestionCursosAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
namespace GestionCursosAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProfesoresController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ProfesoresController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetProfesores()
        {
            List<Profesores> profesores = new List<Profesores>();
            string connectionString = _configuration.GetConnectionString("Connection");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT Id, Nombre, Apellido, FechaNacimiento, Email, Direccion, Telefono FROM Profesores";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    profesores.Add(new Profesores
                    {
                        Id = reader["Id"].ToString(),
                        Nombre = CapitalizeFirstLetter(reader["Nombre"].ToString()),
                        Apellido = CapitalizeFirstLetter(reader["Apellido"].ToString()),
                        FechaNacimiento = Convert.ToDateTime(reader["FechaNacimiento"]),
                        Email = reader["Email"].ToString(),
                        Direccion = CapitalizeFirstLetter(reader["Direccion"].ToString()),
                        Telefono = reader["Telefono"].ToString(),
                    });
                }

                conn.Close();
            }

            return Ok(profesores);
        }



        [HttpPost]
        public IActionResult InsertarProfesor([FromBody] Profesores nuevProfesor)
        {
            if (string.IsNullOrEmpty(nuevProfesor.Id) || nuevProfesor.Id.Length != 10)
            {
                return BadRequest("La cédula es obligatoria y debe tener 10 dígitos.");
            }

            if (!EsCedulaValida(nuevProfesor.Id))
            {
                return BadRequest("La cédula ingresada no es válida.");
            }

            nuevProfesor.Nombre = CapitalizeFirstLetter(nuevProfesor.Nombre);
            nuevProfesor.Apellido = CapitalizeFirstLetter(nuevProfesor.Apellido);
            nuevProfesor.Direccion = CapitalizeFirstLetter(nuevProfesor.Direccion);

            string connectionString = _configuration.GetConnectionString("Connection");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Profesores (Id, Nombre, Apellido, FechaNacimiento, Email, Direccion, Telefono)
                 VALUES (@Id, @Nombre, @Apellido, @FechaNacimiento, @Email, @Direccion, @Telefono)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", nuevProfesor.Id);
                cmd.Parameters.AddWithValue("@Nombre", nuevProfesor.Nombre);
                cmd.Parameters.AddWithValue("@Apellido", nuevProfesor.Apellido);
                cmd.Parameters.AddWithValue("@FechaNacimiento", nuevProfesor.FechaNacimiento);
                cmd.Parameters.AddWithValue("@Email", nuevProfesor.Email);
                cmd.Parameters.AddWithValue("@Direccion", nuevProfesor.Direccion);
                cmd.Parameters.AddWithValue("@Telefono", nuevProfesor.Telefono);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            return Ok(new { message = "Profesores insertado correctamente ✅" });
        }

        private static bool EsCedulaValida(string cedula)
        {
            if (cedula.Length != 10 || !cedula.All(char.IsDigit))
                return false;

            int digitoRegion = int.Parse(cedula.Substring(0, 2));
            if (digitoRegion < 1 || digitoRegion > 24)
                return false;

            int ultimoDigito = int.Parse(cedula[9].ToString());

            int sumaPares = int.Parse(cedula[1].ToString()) +
                            int.Parse(cedula[3].ToString()) +
                            int.Parse(cedula[5].ToString()) +
                            int.Parse(cedula[7].ToString());

            int sumaImpares = 0;
            for (int i = 0; i < 9; i += 2)
            {
                int num = int.Parse(cedula[i].ToString()) * 2;
                if (num > 9) num -= 9;
                sumaImpares += num;
            }

            int sumaTotal = sumaPares + sumaImpares;
            int digitoValidador = 10 - (sumaTotal % 10);
            if (digitoValidador == 10) digitoValidador = 0;

            return digitoValidador == ultimoDigito;
        }



        [HttpPut("{id}")]
        public IActionResult ActualizarProfesores(string id, [FromBody] Profesores profesores)
        {
            profesores.Nombre = CapitalizeFirstLetter(profesores.Nombre);
            profesores.Apellido = CapitalizeFirstLetter(profesores.Apellido);
            profesores.Direccion = CapitalizeFirstLetter(profesores.Direccion);

            string connectionString = _configuration.GetConnectionString("Connection");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Profesores SET Nombre = @Nombre, Apellido = @Apellido, FechaNacimiento = @FechaNacimiento, Email = @Email, Direccion = @Direccion, Telefono = @Telefono WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Nombre", profesores.Nombre);
                cmd.Parameters.AddWithValue("@Apellido", profesores.Apellido);
                cmd.Parameters.AddWithValue("@FechaNacimiento", profesores.FechaNacimiento);
                cmd.Parameters.AddWithValue("@Email", profesores.Email);
                cmd.Parameters.AddWithValue("@Direccion", profesores.Direccion);
                cmd.Parameters.AddWithValue("@Telefono", profesores.Telefono);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            return Ok(new { message = "Profesor actualizado correctamente." });
        }


        [HttpDelete("cedula/{cedula}")]
        public IActionResult EliminarPorCedula(string cedula)
        {
            string connectionString = _configuration.GetConnectionString("Connection");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Profesores WHERE Cedula = @Cedula";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Cedula", cedula);

                conn.Open();
                int filas = cmd.ExecuteNonQuery();
                conn.Close();

                if (filas == 0)
                    return NotFound();

                return Ok(new { message = "Profesores eliminado correctamente." });
            }
        }

        private static string CapitalizeFirstLetter(string input)
        {
            return string.IsNullOrEmpty(input) ? input : char.ToUpper(input[0]) + input.Substring(1).ToLower();
        }
    }
}
